const viewTodo = (todo) => {
  console.log(todo);
};
